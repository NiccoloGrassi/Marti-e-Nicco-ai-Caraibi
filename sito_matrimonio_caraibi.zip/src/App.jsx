
export default function App() {
  return (
    <div className="min-h-screen p-6 backdrop-blur-sm">
      <div className="max-w-4xl mx-auto space-y-10">
        <header className="text-center">
          <h1 className="text-4xl font-bold">Il nostro viaggio di nozze ai Caraibi</h1>
          <p className="text-lg mt-4">Se vuoi farci un regalo, scegli una delle esperienze del nostro viaggio! Puoi contribuire via PayPal o bonifico bancario (IBAN: <b>IT37D0306937898100000000618</b>, specifica l’esperienza nella causale).</p>
        </header>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">

        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Colazione caraibica in spiaggia" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Colazione caraibica in spiaggia</h3>
          <p className="text-lg">50€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Cocktail al tramonto" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Cocktail al tramonto</h3>
          <p className="text-lg">50€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Souvenir artigianale" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Souvenir artigianale</h3>
          <p className="text-lg">50€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Lezione di ballo caraibico" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Lezione di ballo caraibico</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Escursione in catamarano" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Escursione in catamarano</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Gita alle cascate tropicali" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Gita alle cascate tropicali</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Cena romantica sulla spiaggia" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Cena romantica sulla spiaggia</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Tour storico della città" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Tour storico della città</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Massaggio di coppia" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Massaggio di coppia</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Snorkeling nella barriera" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Snorkeling nella barriera</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Passeggiata a cavallo sulla sabbia" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Passeggiata a cavallo sulla sabbia</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Giornata in villaggio locale" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Giornata in villaggio locale</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Noleggio scooter per l’isola" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Noleggio scooter per l’isola</h3>
          <p className="text-lg">100€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Ingresso spa caraibica" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Ingresso spa caraibica</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/rum.jpg" alt="Degustazione di rum" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Degustazione di rum</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Avventura in kayak" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Avventura in kayak</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Tour in jeep nella giungla" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Tour in jeep nella giungla</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Workshop di cucina creola" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Workshop di cucina creola</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Esperienza di pesca locale" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Esperienza di pesca locale</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Serata danzante caraibica" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Serata danzante caraibica</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Visita a piantagione di cacao" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Visita a piantagione di cacao</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Gita in motoscafo" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Gita in motoscafo</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Tour fotografico all’alba" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Tour fotografico all’alba</h3>
          <p className="text-lg">150€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Gita di un giorno su isola deserta" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Gita di un giorno su isola deserta</h3>
          <p className="text-lg">200€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/rum.jpg" alt="Esperienza diving subacquea" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Esperienza diving subacquea</h3>
          <p className="text-lg">200€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Cena gourmet a 5 portate" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Cena gourmet a 5 portate</h3>
          <p className="text-lg">200€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Giornata in beach club esclusivo" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Giornata in beach club esclusivo</h3>
          <p className="text-lg">200€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Lezione privata di surf" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Lezione privata di surf</h3>
          <p className="text-lg">200€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/rum.jpg" alt="Weekend in resort esclusivo" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Weekend in resort esclusivo</h3>
          <p className="text-lg">300€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/cocktail.jpg" alt="Crociera al tramonto" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Crociera al tramonto</h3>
          <p className="text-lg">300€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Tour in elicottero panoramico" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Tour in elicottero panoramico</h3>
          <p className="text-lg">300€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/souvenir.jpg" alt="Notte in villa privata sul mare" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Notte in villa privata sul mare</h3>
          <p className="text-lg">500€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/colazione.jpg" alt="Pacchetto benessere completo" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Pacchetto benessere completo</h3>
          <p className="text-lg">500€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        <div className="rounded-xl bg-white bg-opacity-10 shadow-xl p-4">
          <img src="/images/rum.jpg" alt="Esperienza lusso: yacht privato per un giorno" className="w-full h-48 object-cover rounded-xl mb-2" />
          <h3 className="text-xl font-bold">Esperienza lusso: yacht privato per un giorno</h3>
          <p className="text-lg">1000€</p>
          <div className="flex gap-2 mt-2">
            <a href="https://www.paypal.com/paypalme/martinaeniccolo" target="_blank">
              <button className="bg-blue-500 px-4 py-2 rounded-xl text-white">Regala con PayPal</button>
            </a>
            <button
              onClick={() => navigator.clipboard.writeText('IT37D0306937898100000000618')}
              className="bg-green-500 px-4 py-2 rounded-xl text-white"
            >
              Copia IBAN
            </button>
          </div>
        </div>
        </div>
      </div>
    </div>
  )
}
